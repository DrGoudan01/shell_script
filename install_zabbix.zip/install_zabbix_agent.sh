#!/bin/bash

##  install zabbix agent script

# 创建 zabbix 系统用户
Add_Zabbix_User(){
	/usr/bin/id zabbix >& /dev/null 
	if [[ $? -eq 1 ]]; then
		useradd -M -s /sbin/nologin zabbix > /dev/null 2>&1
		if [[ $? -eq 0 ]]; then
			echo "username:  zabbix  create success !" && /usr/bin/id zabbix;
		else
			echo "username:  zabbix  create fail !";
		fi
	else
		echo "username:  zabbix  exists !"
	fi
	sleep 3
}


# 安装 plugin
Install_Plugin(){
	cd ${PacketDir}
	test -f fping-2.4b2-10.el6.x86_64.rpm && rpm -ivh fping-2.4b2-10.el6.x86_64.rpm
} 


# 配置文件差异化
Make_Config(){
	cd ${PacketDir}
	cp zabbix_agentd.conf zabbix_agentd.conf.bak
	sed -i "s/Template_file/${Hostname}/g" zabbix_agentd.conf.bak
	[ $? == 0 ] && cp zabbix_agentd.conf.bak /usr/local/zabbix/etc/zabbix_agentd.conf
	[ $? == 1 ] && echo "zabbix_agentd configure error"
	echo "configure complete"
}


# 添加控制脚本以及开机启动
Add_Control(){
	cd ${PacketDir}
	cp -f zabbix_agentd /etc/init.d/ && chmod 755 /etc/init.d/zabbix_agentd
	[ $? == 0 ] && chkconfig --add zabbix_agentd
	[ $? == 0 ] && chkconfig --level 35 zabbix_agentd on
	[ $? == 0 ] && service zabbix_agentd start
	if [[ `ps aux | grep zabbix_agentd | head -1 | awk '{print $2}'` != "0" ]]; then
		echo "run zabbix_agentd success!"
	else
		echo "run zabbix_agentd fail, please check!"
	fi
	rm -rf ${PacketDir}/zabbix-3.0.9/
}


# zabbix agent 编译安装
Install_Agent(){
	cd ${PacketDir}
	tar -zxf zabbix-3.0.9.tar.gz
	if [[ $? == 0 ]]; then
		cd zabbix-3.0.9
		./configure --prefix=/usr/local/zabbix --enable-agent
		[ $? == 0 ] && make 
		[ $? == 0 ] && make install
		mkdir -p /usr/local/zabbix/log/ && chown -R zabbix.zabbix /usr/local/zabbix
		echo "install complete"
		sleep 3
	fi
}

# zabbix 运行状态检查
Check_Status(){
if [[ -f "/usr/local/zabbix/sbin/zabbix_agentd" ]]; then
	echo "zabbix agent exists"
else
	echo "zabbix agent not exists"
fi
sleep 3
Status=`ps aux | grep zabbix_agentd | head -1 | awk '{print $2}'`
if [[ ${Status} == "0" ]]; then
	echo "zabbix agent running"
else
	echo "no zabbix agent running"
fi
sleep 3
#read -p "install query : "  query
#case $query in
#	'no' )
#			echo "stop install"
#			exit
#		;;
#	'yes' )
#			continue
#		;;
#	* )
#			echo "argv error"
#			exit
#		;;		
#esac
}


######
## running
######

PacketDir=`pwd`
Hostname=""
if [[ ${Hostname} == "" ]]; then
	echo "Hostname not set"
	exit
fi

Check_Status
Add_Zabbix_User
Install_Agent
#Install_Plugin
Make_Config
Add_Control

