#!/bin/bash

#安装环境
exe_yum(){
   echo "正在安装环境"
   yum install rrdtool fping echoping curl perl-rrdtool perl-Net-Telnet perl-Net-DNS perl-LDAP perl-CGI-SpeedyCGI \
   perl-libwww-perl perl-RadiusPerl perl-IO-Socket-SSL perl-Socket rrdtool* fcgi-perl \
   wqy-microhei-fonts.noarch -y 
   echo "环境安装完成"
   echo "..."
}

#安装perl
install_perl(){
   tar -zxvf perl-5.26.2.tar.gz
   cd perl-5.26.2
   ./Configure -des -Dprefix=$HOME/localperl 
   make
   make test
   make install
   cd ../
}
#安装IO-ALL
install_IO-ALL(){
   tar -zxvf IO-All-0.86.tar.gz
   cd IO-All-0.86
   perl Makefile.PL
   make && make install
   cd ../
}
#安装smokeping
install_smokeping(){
   tar -zxvf smokeping-2.6.8.tar.gz
   cd smokeping-2.6.8
   ./setup/build-perl-modules.sh /usr/local/smokeping/thirdparty
   ./configure --prefix=/usr/local/smokeping > install_smokeping.lock
   flag_1=`cat install_smokeping.lock |grep gmake`
   if [[ flag_1 != "" ]];then
      /usr/bin/gmake install
      rm -f  install_smokeping.lock
      cd ../
      mv ${install_dir}/smokeping /etc/init.d/smokeping
      chmod 755 /etc/init.d/smokeping
   else
      echo "编译失败，检查文件install_smokeping.lock"
      exit
}
#创建必要文件,根据nginx的使用用户选择nobody还是game
dir_make(){
   cd $smokeping_dir
   mkdir cache data var
   chown -R nobody.nobody /usr/local/smokeping
   #创建日志文件
   touch /var/log/smokeping.log
   chown nobody.nobody /var/log/smokeping.log
   #修改配置文件
   mv ${smokeping_dir}/htdocs/smokeping.fcgi.dist  ${smokeping_dir}/htdocs/smokeping.fcgi
   mv ${install_dir}/config ${smokeping_dir}/etc/config
   #修改密钥文件权限
   chmod 600 ${smokeping_dir}/etc/smokeping_secrets.dist
   #配置nginx-fcgi
   mv ${install_dir}/nginx-fcgi /etc/nginx-fcgi
   chown 777 /etc/nginx-fcgi
   ln -s /usr/local/smokeping/cache/ /usr/local/smokeping/htdocs/
   #启动nginx-fcgi
   /etc/nginx-fcgi -l /var/log/nginx-fcgi.log -pid /var/run/nginx-fcgi.pid -S /var/run/nginx-fcgi.sock
   chown nobody.nobody /var/run/nginx-fcgi.sock
}

#控制nginx-fcgi
control_nginx-cgi(){
   echo "0"
}

#添加nginx配置
nginx_set(){
   mv ${install_dir}/fcgi_params  /usr/local/nginx/conf/fcgi_params
   mv ${install_dir}/q-dazzle.com.conf /usr/local/nginx/conf/vhost/smokeping-${IP}.q-dazzle.com.conf
   sed -i "s/T.q-dazzle.com/smokeping-${IP}.q-dazzle.com/g" /usr/local/nginx/conf/vhost/smokeping-${IP}.q-dazzle.com.conf
   /etc/init.d/nginx reload
}
#





######
##1111

#####
install_dir=`dirname $0`
cd $install_dir
smokeping_dir="/usr/local/smokeping"
IP=$1
if [[ ${IP} == "" ]];then
   echo "输入：$0 本机外网IP"
   echo "例如：$0 192.168.0.0 "
   exit
fi
#创建日志目录
mkdir install_log
log_dir=${install_dir}/install_log
echo "安装环境，稍等"
echo "..."
exe_yum >> ${log_dir}/exe_yum.log 2>&1
echo "环境安装完成，日志名为exe_yum.log"
echo ""
echo "编译安装软件包"
echo "编译perl中..."
install_perl >> ${log_dir}/install_perl.log 2>&1
echo "编译smopking中"
install_smokeping >> ${log_dir}/install_smokeping.log 2>&1
tail ${log_dir}/install_smokeping.log
echo "编译IO中" 
install_IO-ALL >> ${log_dir}/install_IO-ALL.log 2>&1
echo "添加fcgi配置并启动"
dir_make
echo "启动完成，注意提示信息"
echo "..."
echo "添加nginx配置，并重载nginx..."
nginx_set
echo "reload完成"
echo "正在启动smokeping"
/etc/init.d/smokeping start
/etc/init.d/smokeping status
echo "smokeping已经启动"
echo "smokeping域名为smokeping-${IP}.q-dazzle.com.conf，对应ip为${IP}"


